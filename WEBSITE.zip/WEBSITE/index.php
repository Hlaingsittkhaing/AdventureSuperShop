<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Adventure Super Shop</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"  />
</head>
<body>

<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand" href="#">Adventure Super Shop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav m-auto my-2 my-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="index.php">HOME</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html">ABOUT</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contactus.html">CONTACT US</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="product.html">PRODUCT</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="cart.html">CART</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn0" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

<section class="main">
  <div class="container py-5">
    <div class="row py-4">
      <div class="col-lg-7 pt-5 text-center">
        <h1 class="pt-5">Chill, explore, and enjoy life’s moments with happy camping adventures.</h1>
        <button class="btn0 mt-3"><a href="product.html">MORE TIPS</a></button>
      </div>
    </div>
  </div>
</section>



<section class="product">
  <div class="container py-5">
    <div class="row py-5">
      <div class="col-lg-5 m-auto text-center">
        <h1>What's Trending</h1>
        <h6 style="color: red;">Chill your life with happiness!</h6>
      </div>
    </div>
    <div class="row">       
  <div class="col-lg-3 text-center">         
    <div class="card border-0 bg-light mb-2">           
      <div class="card-body">             
        <img src="img/candle.jpg" class="img-fluid" alt="">           
      </div>           
      <h6>Candle</h6>           
      <p>$10.99</p>  
      <div class="d-flex justify-content-center mt-3">
        <button class="btn1"><a href="cart.html">Add To Cart</a></button>
      </div>
    </div>       
  </div>       

  <div class="col-lg-3 text-center">         
    <div class="card border-0 bg-light mb-2">           
      <div class="card-body">             
        <img src="img/lantern.webp" class="img-fluid" alt="">           
      </div>           
      <h6>Lantern</h6>           
      <p>$15.99</p>  
      <div class="d-flex justify-content-center mt-3">
        <button class="btn1"><a href="cart.html">Add To Cart</a></button>
      </div>
    </div>       
  </div>       

  <div class="col-lg-3 text-center">         
    <div class="card border-0 bg-light mb-2">           
      <div class="card-body">             
        <img src="img/backpack.webp" class="img-fluid" alt="">           
      </div>           
      <h6>Backpack</h6>           
      <p>$29.99</p>  
      <div class="d-flex justify-content-center mt-3">
        <button class="btn1"><a href="cart.html">Add To Cart</a></button>
      </div>
    </div>       
  </div>       

  <div class="col-lg-3 text-center">         
    <div class="card border-0 bg-light mb-2">           
      <div class="card-body">             
        <img src="img/tent.webp" class="img-fluid" alt="">           
      </div>           
      <h6>Tent</h6>           
      <p>$49.99</p>  
      <div class="d-flex justify-content-center mt-3">
        <button class="btn1"><a href="cart.html">Add To Cart</a></button>
      </div>
    </div>       
  </div>     
</div>

    </div>
  </div>
</section>
<section class="about">
  <div class="container py-5"><div class="row py-5">
    <div class="col-lg-8 m-auto text-center">
      <h1>Welcome to Our Adventure Super Shop Society.</h1>
    </div>
    <div class="row">
      <div class="col-lg-4 text-center">
        <img src="img/s.jpg" class="image-fluid mb-3" alt="">
        <h5>Best Qulity Backpack</h5>
        <p class="text-justify">Trips of 5 days or more usually call for packs of 70 liters or more. These are also usually the preferred choice for winter treks lasting more than 1 night. (Larger packs can more comfortably accommodate extra clothing, a warmer sleeping bag and a 4-season tent, which typically includes extra poles.) They're also a good option for folks taking young children backpacking because Mom and Dad wind up carrying a lot of kids' gear. </p>
      </div>
      <div class="col-lg-4 text-center">
        <img src="img/images.jpg" class="image-fluid mb-3" alt="">
        <h5>Best Qulity Tent</h5>
        <p class="text-justify">When testing family camping tents and instant tents, we loved this option for its blackout interior that keeps it cool in the heat and dark in the early mornings. With an 8-by-7-foot wingspan and a nearly 5-foot center height, even the smallest model lets you stand up in this tent and offers enough room to fit a queen-size blow-up mattress or four sleeping bags side-to-side.</p>
      </div>
      <div class="col-lg-4 text-center">
        <img src="img/best latern.jpg" class="image-fluid mb-3" alt="">
        <h5>Best Qulity Lantern</h5>
        <p class="text-justify">While there isn’t a single best camping lantern for everyone, we sure looked for one. We’ve tested nearly 40 different light sources across half a decade of camping seasons to pull together a list of the most worthy light sources to bring on your next wilderness outing. Our choices have traveled with us from the dark deserts of Joshua Tree to the green tunnels of the Appalachian Trail, and we weren’t gentle on them, either.</p>
      </div>
    </div>
  </div>
  <div class="row py-3">
      <div class="col-lg-6 text-center m-auto">
        <button class="btn0"><a href="product.html">Show More</a></button>
      </div>
    </div>
</div>
</section>
<section class="gallery py-5">
  <div class="container text-center">
    <h1>Our Gallery</h1>
    <p>Explore some of the best moments from our adventures</p>
    <div id="galleryCarousel" class="carousel slide mt-4" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="img/pixel-art-camping-forest-with-tents-bonfires-river-mountains-landscape-8-bit-game-ai_985124-9259.jpg" class="d-block w-100" alt="Gallery Image 1">
        </div>
        <div class="carousel-item">
          <img src="img/pixel-art-camping-landscape-with-tent_762785-37562.avif" class="d-block w-100" alt="Gallery Image 2">
        </div>
        <div class="carousel-item">
          <img src="img/pixel-art-camping-woods-campsite-with-trailer-campfire-landscape-8-bit-game-ai_985124-1655.avif" class="d-block w-100" alt="Gallery Image 3">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#galleryCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#galleryCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  </div>
</section>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
<footer class="bg-dark text-light py-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-md-6 mb-3">
        <h5>Explore</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-light text-decoration-none">Shop Gear</a></li>
          <li><a href="#" class="text-light text-decoration-none">New Arrivals</a></li>
          <li><a href="#" class="text-light text-decoration-none">Best Sellers</a></li>
          <li><a href="#" class="text-light text-decoration-none">Adventure Kits</a></li>
          <li><a href="#" class="text-light text-decoration-none">Outdoor Essentials</a></li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-6 mb-3">
        <h5>Support</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-light text-decoration-none">Help Center</a></li>
          <li><a href="#" class="text-light text-decoration-none">Shipping Info</a></li>
          <li><a href="#" class="text-light text-decoration-none">Returns & Exchanges</a></li>
          <li><a href="#" class="text-light text-decoration-none">Order Tracking</a></li>
          <li><a href="#" class="text-light text-decoration-none">Contact Us</a></li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-6 mb-3">
        <h5>About</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-light text-decoration-none">Our Story</a></li>
          <li><a href="#" class="text-light text-decoration-none">Sustainability</a></li>
          <li><a href="#" class="text-light text-decoration-none">Careers</a></li>
          <li><a href="#" class="text-light text-decoration-none">Affiliate Program</a></li>
          <li><a href="#" class="text-light text-decoration-none">Blog & Tips</a></li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-6 mb-3">
        <h5>Join Our Adventure</h5>
        <p>Get exclusive offers, outdoor tips, and new gear updates.</p>
        <form>
          <div class="input-group">
            <input type="email" class="form-control" placeholder="Email address">
            <button class="btn color-black" type="submit"><a href="login.html">Subscribe</a></button>
          </div>
        </form>
      </div>
    </div>
    <div class="d-flex justify-content-between align-items-center mt-4">
      <p class="mb-0">&copy; 2025 Adventure Super Shop. All rights reserved.</p>
      <div>
        <a href="#" class="text-light me-3"><i class="fa-brands fa-square-x-twitter"></i></a>
        <a href="#" class="text-light me-3"><i class="fa-brands fa-instagram"></i></a>
        <a href="#" class="text-light"><i class="fa-brands fa-square-facebook"></i></a>
        <a href="#" class="text-light me-3"><i class="fa-brands fa-square-whatsapp"></i></a>
      </div>
    </div>
  </div>
</footer>


</html>